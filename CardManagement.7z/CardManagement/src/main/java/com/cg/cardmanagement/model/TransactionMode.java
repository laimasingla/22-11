
package com.cg.cardmanagement.model;

public enum TransactionMode {


	ONLINE, CASH;
}

