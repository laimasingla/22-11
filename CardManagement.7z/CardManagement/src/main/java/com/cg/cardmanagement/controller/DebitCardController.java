package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.DebitCardBean;
import com.cg.cardmanagement.model.DebitCardTransaction;
import com.cg.cardmanagement.service.DebitCustomer;
import com.cg.cardmanagement.service.DebitCustomerVerification;

@RestController
@Scope("session")
@RequestMapping("/debit")
public class DebitCardController {
	BigInteger cardNumber;
	BigInteger debitCard;
	@Autowired
	private DebitCustomer debitService;
	@Autowired
	private DebitCustomerVerification debitVerify;

	@GetMapping("/debitlist")
	public ResponseEntity<List<DebitCardBean>> list() {
		List<DebitCardBean> debitCardBeans = null;
		try {
			debitCardBeans = debitService.viewAllDebitCards();
		} catch (IBSException e) {
			// String message = e.getMessage();
			// return new ModelAndView("errorPage", "errorMessage", message);
		}
		return new ResponseEntity<List<DebitCardBean>>(debitCardBeans, HttpStatus.OK);
	}

	/*
	 * @RequestMapping("/customer") public ModelAndView showCardHome() { return new
	 * ModelAndView("cardsHomePage"); }
	 */

	@GetMapping("/carddisplaymenu/{cardNumber}")
	public ResponseEntity<DebitCardBean> cardDetails(@PathVariable("cardNumber") BigInteger cardNumber) {
		DebitCardBean debitBean = new DebitCardBean();
		try {
			debitBean = debitService.fetchDebitdetails(cardNumber);
		} catch (IBSException e) {
		}
		return new ResponseEntity<DebitCardBean>(debitBean, HttpStatus.OK);
	}

	/*
	 * @RequestMapping("/back") public String back() { return "cardsDetailsPage"; }
	 * 
	 * @RequestMapping("/cardMainMenu") public String showMenu() { return
	 * "cardsMenuPage"; }
	 * 
	 * @RequestMapping("/cardSubMenu") public String showCardMenu() { return
	 * "cardsSubMenuPage"; }
	 */

//	@GetMapping(value = "/block")
//	public ResponseEntity<String> block() {
//		String output = "";
//		debitCard = this.cardNumber;
//
//		try {
//			if (!debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Blocked")) {
//				return new ModelAndView("activateCardPage");
//			} else {
//				output = "This card is already blocked!";
//			}
//			return new ModelAndView("outputPage", "output", output);
//		} catch (IBSException e) {
//			output = e.getMessage();
//			return new ModelAndView("errorPage", "output", output);
//		}
//	}

	@PatchMapping(value = "/block/{cardNumber}/{pin}")
	public ResponseEntity<String> block(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) {
		String output = "";

		try {
			if (!debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					debitService.requestDebitCardLost(cardNumber);
					output = " Your card has been Blocked. Contact branch for further process!";
				} else {
					output = "Card number and pin don't match!! Try again!";
				}
			} else {

				output = "Card already blocked";
			}
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}

	}

//	@PostMapping(value = "/activate")
//	public ResponseEntity<String> activate() {
//		String output = "";
//		try {
//			if (debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Inactive")) {
//				return new ResponseEntity<String>(output,HttpStatus.OK);
//			}
//
//			else {
//				output = "OOPS!! This card is either Blocked or already active and can not be activated";
//				return new ModelAndView("outputPage", "output", output);
//			}
//		} catch (IBSException e) {
//			output = e.getMessage();
//			return new ModelAndView("errorPage", "output", output);
//		}
//	}

	@PatchMapping(value = "/activate/{cardNumber}/{pin}")
	public ResponseEntity<String> activate(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) {
		String output = "";

		try {
			if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					debitService.activateDebitCard(cardNumber);
					output = "Card successfully activated!";
				} else {
					output = "Card number and pin don't match!! Try again!";
				}
			} else {

				output = "Card already Active/Blocked";
			}
			return new ResponseEntity<String>(output, HttpStatus.OK);

		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}

	@PatchMapping(value = "/deactivate/{cardNumber}/{pin}")
	public ResponseEntity<String> deactivate(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) {
		String output = "";
		try {

			if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {

				if (debitVerify.verifyDebitPin(pin, cardNumber)) {

					debitService.deactivateDebitCard(cardNumber);
					output = "Card successfully deactivated!";
				} else {
					output = "Card number and pin don't match!! Try again!";
				}
			} else {
				output = "Your card is Blocked/Inactive";

			}
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}

	@PatchMapping(value = "/resetpin/{cardNumber}/{newpin}/{newpin2}/{pin}")
	public ResponseEntity<String> resetPin2(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("newpin") String newpin, @PathVariable("newpin2") String newpin2,
			@PathVariable("pin") String pin) {
		String output = "";
		try {

			if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {

				if (debitVerify.verifyDebitPin(pin, cardNumber)) {

					if (newpin2.equals(newpin)) {
						debitService.resetDebitPin(cardNumber, newpin);
						output = "PIN SUCCESSFULLY CHANGED";
					} else {
						output = "PINS DO NOT MATCH!! TRY AGAIN";
					}
					return new ResponseEntity<String>(output, HttpStatus.OK);
				} else {
					output = "Card number and pin don't match!! Try again!";

				}

			} else {

				output = "Your Card is Blocked . Cannot change pin!";
			}
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}

	@PostMapping(value = "/upgrade")
	public ResponseEntity<String> upgrade(@RequestBody CaseIdBean caseIdBean) {

		String type = caseIdBean.getDefineServiceRequest();
		BigInteger cardNumber = caseIdBean.getCardNumber();
		String remarks = caseIdBean.getCustomerRemarks();

		String output = "";

		try {

			if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {

				String initialType = debitService.getDebitcardType(cardNumber);
				if (initialType.equalsIgnoreCase("Silver")) {
					if (type.equalsIgnoreCase("Gold") || type.equalsIgnoreCase("Platinum")) {
						String num = debitService.requestDebitCardUpgrade(cardNumber, type, remarks);
						output = "Ticket Raised successfully. Your reference Id is" + num;

					} else {

						output = "you can only upgrade to Gold/platinum";
					}

				} else

				if (initialType.equalsIgnoreCase("Gold")) {

					if (type.equalsIgnoreCase("Platinum")) {
						String num = debitService.requestDebitCardUpgrade(cardNumber, type, remarks);
						output = "Ticket Raised successfully. Your reference Id is" + num;

					} else {

						output = "you can only upgrade to Platinum";
					}

				}

				else

				if (initialType.equalsIgnoreCase("Platinum")) {

					output = "Highest level .Cannot upgrade any further";

				} else {

					output = "Invalid Card Type";
				}

			} else {
				output = "Cannot upgrade Inactive or Blocked card";
			}
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}

	@GetMapping(value = "/requestStatement/{cardNumber}/{fromdate}/{enddate}")
	public ResponseEntity<List<DebitCardTransaction>> requestStatement(

			@PathVariable("cardNumber") BigInteger cardNumber, @PathVariable("fromdate") String fromdate,
			@PathVariable("enddate") String enddate) {

		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

		try {
			LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
			LocalDate endDate1 = LocalDate.parse(enddate, formatter);
			List<DebitCardTransaction> bean1 = debitService.getDebitTransactions(startDate1, endDate1, cardNumber);
			return new ResponseEntity<List<DebitCardTransaction>>(bean1, HttpStatus.OK);

		} catch (IBSException e) {
			// String output = e.getMessage();
			return new ResponseEntity<List<DebitCardTransaction>>(HttpStatus.OK);
		}
	}

	@GetMapping(value = "/mismatchDebit/{transactionId}/{remarks}")
	public ResponseEntity<String> debitMismatch(@PathVariable("transactionId") BigInteger transactionId,
			@PathVariable("remarks") String remarks) {
		String output = "";

		try {
			String refId = debitService.raiseDebitMismatchTicket(transactionId, remarks);
			output = " Ticket raised successfully. your reference ID is " + refId;
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}

	@GetMapping(value = "/applynewdebit/{accNum}/{type}")
	public ResponseEntity<String> applyNewDebitCard2(@PathVariable("accNum") BigInteger accountNumber,
			@PathVariable("type") String type) {
		String output = "";
		try {

			if (debitService.checkDebitCardCount()) {

				String num = debitService.applyNewDebitCard(accountNumber, type);
				output = "Ticket Raised successfully. Your reference Id is" + num;
			} else {
				output = "You already have 3  debit cards.";

			}
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}
}
