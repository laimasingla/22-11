package com.cg.cardmanagement.service;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cardmanagement.dao.CreditCardDao;
import com.cg.cardmanagement.exception.IBSException;

@Service
public class CreditCustomerVerificationImpl implements CreditCustomerVerification {

	@Autowired
	private CreditCardDao creditCardDao;

	@Override
	public boolean verifyCreditPin(String pin, BigInteger creditCardNumber) throws IBSException {
		try {
			if (pin.equals(creditCardDao.getCreditCardPin(creditCardNumber))) {

				return true;
			} else {
				return false;
			}
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public String verifyCreditcardType(BigInteger creditCardNumber) throws IBSException {

		String type;
		try {
			type = creditCardDao.getcreditCardType(creditCardNumber);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return type;

	}

	/*
	 * @Override public boolean verifyCreditCardTransactionId(BigInteger
	 * transactionId) throws IBSException { boolean transactionResult =
	 * creditCardTransactionDao.verifyCreditTransactionId(transactionId); if
	 * (!transactionResult) throw new
	 * IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);
	 * 
	 * return transactionResult; }
	 */
	@Override
	public boolean getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		boolean status = false;
		try {
			String existingStatus = creditCardDao.getCreditCardStatus(creditCardNumber);
			if (!existingStatus.equals("Blocked")) {
				status = true;
			}
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return status;
	}

	@Override
	public boolean checkCreditPin(String pin) throws IBSException {
		boolean check = true;

		String cardPin = pin;
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(cardPin);
		if (!(matcher.find() && matcher.group().equals(cardPin))) {
			check = false;
			throw new IBSException("Incorrect format of pin");
		}

		return check;
	}
}
