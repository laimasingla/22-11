package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.service.CustomerService;

@RestController
public class DefaultController {

	@Autowired
	private CustomerService customerService;

//	@RequestMapping({ "/", "/home" })
//	public String showHome() {
//		return "homePage";
//	}
//
//	@RequestMapping("/menu")
//	public String showMenu() {
//		return "menuPage";
//	}
//
//	@RequestMapping("/customer")
//	public String showCardHome() {
//		return "cardsHomePage";
//	}
//
//	@RequestMapping("/cardChoice")
//	public String showCardHome1() {
//		return "cardMenuPage";
//	}
//
//	@RequestMapping("/debitMenu")
//	public String showdebitMenu() {
//		return "debitMenuPage";
//
//	}
//
//	@RequestMapping("/creditMenu")
//	public String showCreditMenu() {
//		return "creditMenuPage";
//	}
//
//	@RequestMapping("/debitCards")
//	public String showDebitCardHome() {
//		return "debitHomeMenuPage";
//	}
//
//	@RequestMapping("/creditCards")
//	public String showCreditCardHome() {
//		return "creditHomeMenuPage";
//	}
//	// @RequestMapping(value="/errors",method=RequestMethod.GET)
//	// public String error(){
//	// return "pageNotFound";
//	// }
//
//	@RequestMapping("/banker")
//	public String showBankHome() {
//		return "bankHomePage";
//	}
//
//	@RequestMapping("/viewStatus")
//	public String showStatus() {
//		return "queryStatus";
//	}

	@PostMapping(value = "/queryStatus/{UCI}")
	public ResponseEntity<List<CaseIdBean>> viewQueryStatus(@PathVariable("UCI") BigInteger uci) {

		List<CaseIdBean> caseIdBeans;
		try {

			caseIdBeans = customerService.listAllQueries(uci);
			return new ResponseEntity<List<CaseIdBean>>(caseIdBeans, HttpStatus.OK);
		} catch (IBSException e) {
			// String message = e.getMessage();
			return new ResponseEntity<List<CaseIdBean>>(HttpStatus.OK);

		}

	}

	@RequestMapping(value = "/displayServiceRequests")
	public ModelAndView queryStatus(@RequestParam("customerRefId") String customerReferenceId) {
		String output = "";
		try {
			String status = customerService.viewServiceRequestStatus(customerReferenceId);
			output = "Status of your request is '" + status + "'";
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

}
