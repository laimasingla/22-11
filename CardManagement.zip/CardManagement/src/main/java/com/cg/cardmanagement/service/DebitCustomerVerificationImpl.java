package com.cg.cardmanagement.service;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cardmanagement.dao.DebitCardDao;
import com.cg.cardmanagement.exception.IBSException;

@Service
public class DebitCustomerVerificationImpl implements DebitCustomerVerification {

	@Autowired
	private DebitCardDao debitCardDao;

	@Override
	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException {
		try {

			if (pin.equals(debitCardDao.getDebitCardPin(debitCardNumber))) {

				return true;
			} else {
				return false;
			}
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public boolean verifyDebitCardPin(String pin) throws IBSException {

		boolean check = true;
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(pin);
		if (!(matcher.find() && matcher.group().equals(pin))) {
			check = false;
			throw new IBSException("Incorrect format of pin");
		}

		return check;

	}

}
