package com.cg.cardmanagement.dao;

public interface BankDao {

}
